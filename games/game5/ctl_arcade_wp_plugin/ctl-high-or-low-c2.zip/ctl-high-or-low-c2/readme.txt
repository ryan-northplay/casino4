=== CTL High Or Low C2 ===
Tags: ace, android, capx, card, casino, construct, gambling, high or low, html5 casino, html5 gambling, instant win, ios, poker, sweepstakes
Requires at least: 4.3
Tested up to: 4.3

Add High Or Low C2 to CTL Arcade plugin

== Description ==
Add High Or Low C2 to CTL Arcade plugin


	